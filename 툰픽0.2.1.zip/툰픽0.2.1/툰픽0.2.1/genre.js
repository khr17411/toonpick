function setupActiveToggle(filterClassName) {
    const items = document.querySelectorAll(`.${filterClassName} li`);
    
    items.forEach(item => {
      item.addEventListener('click', (e) => {
        e.preventDefault();
        items.forEach(i => i.classList.remove('active'));
        item.classList.add('active');
      });
    });
  }
  
  setupActiveToggle('genre-filter');
  setupActiveToggle('sort-filter');

  // 추가된 부분: 마이페이지 슬라이드 & 탭 전환

const myButton = document.getElementById('my-button');
const mypageContainer = document.getElementById('mypage-container');
const favoritesTab = document.getElementById('favorites-tab');
const recentTab = document.getElementById('recent-tab');
const favoritesList = document.getElementById('favorites-list');
const recentList = document.getElementById('recent-list');

// 사용자 이름 관리
const user_name = "사용자";
document.querySelector('.user-name').innerText = user_name;

// MY 버튼 클릭 → 마이페이지 슬라이드 등장
myButton.addEventListener('click', () => {
    if (mypageContainer.style.display === 'none' || mypageContainer.style.display === '') {
      mypageContainer.style.display = 'block';
      setTimeout(() => {
        mypageContainer.classList.add('show');
        myButton.classList.add('active');
      }, 10); 
    } else {
      mypageContainer.classList.remove('show');
      myButton.classList.remove('active');
      setTimeout(() => {
        mypageContainer.style.display = 'none';
      }, 300); 
    }
  });

// 즐겨찾기 탭 클릭
favoritesTab.addEventListener('click', () => {
  favoritesTab.classList.add('active');
  recentTab.classList.remove('active');
  favoritesList.classList.remove('hidden');
  recentList.classList.add('hidden');
});

// 최근본 탭 클릭
recentTab.addEventListener('click', () => {
    recentTab.classList.add('active');
    favoritesTab.classList.remove('active');
    recentList.classList.remove('hidden');
    favoritesList.classList.add('hidden');
});

//별표 토글
document.querySelectorAll('.favorite-toggle').forEach(button => {
    button.addEventListener('click', () => {
        if (button.classList.contains('active')) {
            button.classList.remove('active');
            button.classList.add('inactive');
        } else {
            button.classList.remove('inactive');
            button.classList.add('active');
        }
    });
});

  // 로그아웃
const logoutButton = document.querySelector('.mypage-buttons button:nth-child(2)');
const logoutModal = document.getElementById('logout-modal');
const cancelLogout = document.getElementById('cancel-logout');
  
logoutButton.addEventListener('click', () => {
    logoutModal.classList.remove('hidden');
});
  
cancelLogout.addEventListener('click', () => {
    logoutModal.classList.add('hidden');
});