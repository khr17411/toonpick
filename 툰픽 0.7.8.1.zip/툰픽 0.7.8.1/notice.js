document.querySelector('.back-button').addEventListener('click', function () {
  window.location.href = 'MyPage.html';
});