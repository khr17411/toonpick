const toggleButtons = document.querySelectorAll('.toggle-group .toggle-btn');

toggleButtons.forEach(button => {
  button.addEventListener('click', () => {
    const siblings = button.parentElement.querySelectorAll('.toggle-btn');
    siblings.forEach(btn => btn.classList.remove('active'));
    button.classList.add('active');
  });
});

document.querySelector('.back-button').addEventListener('click', function () {
  window.location.href = 'MyPage.html';
});